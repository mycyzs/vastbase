## 使用说明

**插件名称**: vastbaseG100数据库监控插件

**插件ID**: cw_vastbaseG100_exporter

### 插件功能

采集器将会根据配置的数据库IP和端口，定期执行查询语句，以获取相应的指标数据。

### 版本支持

**系统支持:**

Linux、Windows

linux实测：centos7

windows实测：Windows 10

**组件支持版本：**

理论上支持：Vastbase2.X

实测支持：Vastbase2.2

**是否支持远程采集:**

是

### 使用指引


### 参数说明

| 参数名      | 含义        | 是否必填 | 举例        |     |
|----------|-----------|------|-----------|-----|
| user     | 数据库用户名    | 是    | vastbase  |     |
| password | 数据库密码     | 是    | 123456    |     |
| host     | 主机ip      | 是    | 127.0.0.1 |     |
| port     | 数据库端口     | 是    | 5432      |     |
| dbname   | 数据库名      | 否    | vastbase  |     |
| loglevel | 日志级别      | 否    | error     |     |
| timeout  | 查询超时时间（s） | 否    | 60        |     |

*参数为空时，应当填上""(英文双引号)*

### 指标列表

#### 基本
| 指标                                               | 指标别名                 | 单位           | 维度                                         | 维度别名                | 备注                         |
|--------------------------------------------------|----------------------|--------------|--------------------------------------------|---------------------|----------------------------|
| vastbaseG100_exporter_up                         | 插件运行状态               | none         |                                            |                     | （1 == active ， 0 == error） |
| vastbaseG100_dbConnectState                         | 数据库连接状态               | none         |                                            |                     | （1 == active ， 0 == error） |


#### 性能
| 指标                                           | 指标别名           | 单位      | 维度                     | 维度别名      | 备注  |
|----------------------------------------------|----------------|---------|------------------------|-----------|-----|
| vastbaseG100_exporter_deadlock_number        | 死锁数            | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_xact_commit            | 已提交事务数         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_xact_trans_ratio       | 事务提交率          | percent | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_xact_rollback          | 已回滚事务数         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_long_xact_num          | 执行时间大于30秒的长事务数 | none    |                        |           |     |
| vastbaseG100_exporter_db_max_tran_duration   | 数据库当前执行查询的最长时间 | s       | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_buffers_hit_ratio      | 缓存命中率          | percent | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_granted_locks          | 数据库中当前已授予的锁数量  | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_db_locks               | 数据库中不同类型锁的数量   | none    | DatabaseName, LockMode | 数据库名, 锁模式 |     |
| vastbaseG100_exporter_tup_returned_number    | 全表扫描记录数        | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_tup_fetched            | 查询抓取行数         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_tup_updated            | 查询更新行数         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_tup_deleted            | 查询删除行数         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_conflicts              | 取消查询数量         | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_temp_files             | 创建临时文件数量       | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_temp_bytes             | 写入临时文件数据总量     | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_blk_read_time          | 读取数据文件块耗时      | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_blk_write_time         | 写入数据文件块耗时      | none    | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_database_used_disk_kb  | 数据库使用的磁盘空间     | kbytes  | DatabaseName           | 数据库名      |     |
| vastbaseG100_exporter_slow_query_number      | 慢查询数量          | none    |                        |           |     |
| vastbaseG100_exporter_buffers_backend        | 后端直接写入的缓冲区数    | none    |                        |           |     |
| vastbaseG100_exporter_buffers_checkpoint     | 检查点期间写入的缓冲区数   | none    |                        |           |     |
| vastbaseG100_exporter_buffers_clean          | 后台编写器写入的缓冲区数   | none    |                        |           |     |
| vastbaseG100_exporter_checkpoint_write_ratio | 检查点期间写入率       | percent |                        |           |     |
| vastbaseG100_exporter_queries_per_second     | 每秒查询次数         | none    |                        |           |     |
| vastbaseG100_exporter_update_per_second      | 每秒更新次数         | none    |                        |           |     |
| vastbaseG100_exporter_read_per_second        | 每秒读取磁盘次数       | none    |                        |           |     |
| vastbaseG100_exporter_blks_read              | 读取磁盘块次数        | none    |                        |           |     |      |
| vastbaseG100_exporter_blks_hit               | 已发现磁盘块次数       | none    |                        |           |     |      |
| vastbaseG100_exporter_delete_per_second      | 每秒删除次数         | none    |                        |           |     |
| vastbaseG100_exporter_insert_per_second      | 每秒插入次数         | none    |                        |           |     |
| vastbaseG100_exporter_fetch_per_second       | 每秒索引扫描回表记录数    | none    |                        |           |     |
| vastbaseG100_exporter_TPS                    | TPS            | none    |                        |           |     |
| vastbaseG100_exporter_QPS                    | QPS            | none    |                        |           |     |
| vastbaseG100_exporter_wait                   | 当前等待事件数量       | none    |                        |           |     |



#### 会话
| 指标                                          | 指标别名    | 单位      | 维度  | 维度别名 | 备注  |
|---------------------------------------------|---------|---------|-----|------|-----|
| vastbaseG100_exporter_max_connections       | 最大会话数   | none    |     |      |     |
| vastbaseG100_exporter_active_connections    | 活跃会话数   | none    |     |      |     |
| vastbaseG100_exporter_num_backends          | 后端连接数   | none    |     |      |     |
| vastbaseG100_exporter_connection_used_ratio | 当前会话数比例 | percent |     |      |     |
| vastbaseG100_exporter_connections           | 数据库连接数  | none    |     |      |     |
| vastbaseG100_exporter_block_connections     | 阻塞会话数   | none    |     |      |     |
| vastbaseG100_exporter_idle_connections      | 空闲会话数   | none    |     |      |     |



#### 安全
| 指标                                    | 指标别名     | 单位   | 维度       | 维度别名 | 备注  |
|---------------------------------------|----------|------|----------|------|-----|
| vastbaseG100_exporter_user_pass_valid | 用户密码到期时间 | days | rolename | 用户名  |     |



#### 备份
| 指标                                               | 指标别名                 | 单位           | 维度                                                                                                                    | 维度别名                                                                    | 备注                                                                                  |
|--------------------------------------------------|----------------------|--------------|-----------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| vastbaseG100_exporter_backup_state               | 主备进程状态               | none         | usename,<br/>application_name,<br/>client_addr,<br/>client_hostname,<br/>client_port,<br/>backendStart,<br/>queryTime | 用户名称,<br/>应用名称,<br/>客户端IP,<br/>客户端名称,<br/>客户端端口,<br/>进程启动时间,<br/>数据查询时间 | 0=无数据,<br/>1=Startup,<br/>2=Catchup2,<br/>3=Streaming,<br/>4=Backup,<br/>5=Stopping |
| vastbaseG100_exporter_backup_syncState           | 主备同步状态               | none         | usename,<br/>application_name,<br/>client_addr,<br/>client_hostname,<br/>client_port,<br/>backendStart,<br/>queryTime | 用户名称,<br/>应用名称,<br/>客户端IP,<br/>客户端名称,<br/>客户端端口,<br/>进程启动时间,<br/>数据查询时间 | 0=无数据,<br/>1=Async,<br/>2=Potential,<br/>3=Sync,<br/>4=Quorum                       |
| vastbaseG100_exporter_slaveLatencyMB             | 备库WAL延迟应用量           | mbytes       | usename,<br/>application_name,<br/>client_addr,<br/>client_hostname,<br/>client_port,<br/>backendStart,<br/>queryTime | 用户名称,<br/>应用名称,<br/>客户端IP,<br/>客户端名称,<br/>客户端端口,<br/>进程启动时间,<br/>数据查询时间 |                                                                                     |
| vastbaseG100_exporter_sendLatencyMB              | 备库WAL延迟接收量           | mbytes       | usename,<br/>application_name,<br/>client_addr,<br/>client_hostname,<br/>client_port,<br/>backendStart,<br/>queryTime | 用户名称,<br/>应用名称,<br/>客户端IP,<br/>客户端名称,<br/>客户端端口,<br/>进程启动时间,<br/>数据查询时间 |                                                                                     |
| vastbaseG100_exporter_flushLatencyMB             | 备库WAL延迟刷盘量           | mbytes       | usename,<br/>application_name,<br/>client_addr,<br/>client_hostname,<br/>client_port,<br/>backendStart,<br/>queryTime | 用户名称,<br/>应用名称,<br/>客户端IP,<br/>客户端名称,<br/>客户端端口,<br/>进程启动时间,<br/>数据查询时间 |                                                                                     |

#### 索引
| 指标                                           | 指标别名      | 单位    | 维度                                         | 维度别名                | 备注  |
|----------------------------------------------|-----------|-------|--------------------------------------------|---------------------|-----|
| vastbaseG100_exporter_index_ipages           | 索引占用块数    | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_index_iotta            | 预估索引块数    | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_index_ibloat           | 索引膨胀倍数    | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_index_wastedpages      | 索引浪费数据块数  | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_index_totalwastedbytes | 索引总浪费空间大小 | bytes | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |



#### 表
| 指标                                       | 指标别名       | 单位    | 维度                                         | 维度别名                | 备注  |
|------------------------------------------|------------|-------|--------------------------------------------|---------------------|-----|
| vastbaseG100_exporter_size_bytes         | 表大小        | bytes | DatabaseName, TableName                    | 数据库名，表名             |     |
| vastbaseG100_exporter_table_bloat_tups   | 表膨胀行数      | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_table_bloat_pages  | 表膨胀占用数据库块数 | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_table_bloat_otta   | 表膨胀预估数据块   | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
| vastbaseG100_exporter_table_bloat_tbloat | 表膨胀倍数      | none  | DatabaseName, SchemaName, TableName, Iname | 数据库名，Schema名，表名，索引名 |     |
  

#### 内存
| 指标                                               | 指标别名                 | 单位           | 维度                              | 维度别名        | 备注  |
|--------------------------------------------------|----------------------|--------------|---------------------------------|-------------|-----|
| vastbaseG100_exporter_memory_info                | 内存使用情况               | mbytes       | memoryType                      | 内存类型        |     |
| vastbaseG100_exporter_process_use_rate           | 数据库进程使用内存占最大可用进程内存比例 | percent(1.0) |                                 |             |     |
| vastbaseG100_exporter_dynamic_use_rate           | 数据库动态内存占最大可用动态内存比例   | percent(1.0) |                                 |             |     |
| vastbaseG100_exporter_shared_use_rate            | 数据库共享内存占最大可用共享内存比例   | percent(1.0) |                                 |             |     |
| vastbaseG100_exporter_tablespace_total_usedmsize | 表已用空间大小              | mbytes       | spcname, pg_tablespace_location | 表空间名称，表空间位置 |     |


### 版本日志

#### cw_vastbaseG100_exporter 1.0.0

- 标准化框架