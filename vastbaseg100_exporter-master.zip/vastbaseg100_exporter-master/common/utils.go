package common

import (
	"crypto/rand"
	"crypto/rsa"
	"crypto/x509"
	"encoding/base64"
	"encoding/pem"
	"fmt"
	"os"
	"os/exec"
	"strings"
)

func ExecShell(command string) (string, error) {
	cmd := exec.Command("/bin/bash", "-c", command)
	output, err := cmd.Output()
	if err != nil {
		return "", err
	}
	str := strings.TrimSuffix(strings.TrimSpace(string(output)), "\n")
	return str, nil
}

// RSADecrypt 解密
func RSADecrypt(cipherText string, privateKey []byte) ([]byte, error) {
	// 先base64解码
	data, err := base64.StdEncoding.DecodeString(cipherText)
	if err != nil {
		return nil, err
	}
	//pem解码
	block, _ := pem.Decode(privateKey)
	//X509解码
	privateKeyItem, err := x509.ParsePKCS1PrivateKey(block.Bytes)
	if err != nil {
		return nil, err
	}
	//对密文进行解密
	plainText, err := rsa.DecryptPKCS1v15(rand.Reader, privateKeyItem, data)
	if err != nil {
		return nil, err
	}
	//返回明文
	return plainText, nil
}

// 创建文件
func MakeFile(path, file_name string) error {
	// check
	if _, err := os.Stat(path); err == nil {
		fmt.Println("directory already exists")
	} else {
		fmt.Println("make directory success", path)
		err := os.MkdirAll(path, 0766)

		if err != nil {
			fmt.Println("failed to create directory")
			return err
		}
	}
	if _, err := os.Stat(path + file_name); err != nil {
		f, err := os.Create(path + file_name)
		defer f.Close()
		if err != nil {
			fmt.Println("failed to create file")
			return err
		}
	}
	return nil
}
