package common

import (
	"errors"
)

var ValueNotFound = errors.New("value not found")
