package main

import (
	"flag"
	"fmt"
	"net/http"
	collector "vastbase_exporter/collector"
	"vastbase_exporter/common"
	"vastbase_exporter/config"
	"vastbase_exporter/logger"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

//Defining the basic content
var (
	Version       = common.Version
	NameSpace     = common.NameSpace
	listenAddress = flag.String("web.listen-address", ":9601", "Address to listen on for web interface and telemetry.")
	metricPath    = flag.String("web.telemetry-path", "/metrics", "Path under which to expose metrics.")
	landingPage   = []byte("<html><head><title>" + NameSpace + " " + Version + "</title></head><body><h1>" + NameSpace +
		" " + Version + "</h1><p><a href='" + *metricPath + "'>Metrics</a></p></body></html>")
)

//Program entry, collect command line content, register Exporter and listening
func main() {
	var host string
	flag.StringVar(&host, "host", "127.0.0.1", "host")
	var port string
	flag.StringVar(&port, "port", "5432", "port")
	var user string
	flag.StringVar(&user, "user", "", "user")
	var password string
	flag.StringVar(&password, "password", "", "password")
	var dbname string
	flag.StringVar(&dbname, "dbname", "vastbase", "dbname")
	var logLevel string
	flag.StringVar(&logLevel, "logLevel", "error", "logLevel")
	var timeout string
	flag.StringVar(&timeout, "timeout", "60", "timeout(s)")
	flag.Parse()
	logging := logger.GetStdLogger()
	logging.SetLevel(logLevel)
	if host == "" || port == "" {
		logging.Errorf("host or port is needed")
	}
	if user == "" {
		logging.Errorf("user is needed")
	}
	if password == "" {
		logging.Errorf("password is null,please set password")
	}

	logging.Debugf("Input password: %v", password)
	passwd, err := common.RSADecrypt(password, []byte(common.PrivateKey))
	if err == nil {
		password = string(passwd)
		logging.Debugf("Decrypted password: %v", password)
	} else {
		logging.Errorf("RSADecrypt Error: %v [Try to use plain password.....]", err)
	}

	logging.Infof("Starting %s %s", NameSpace, Version)

	conf := &config.Config{
		Host:     host,
		Port:     port,
		User:     user,
		Password: password,
		LogLevel: logLevel,
		Dsn:      fmt.Sprintf("postgresql://%v:%v@%v:%v/%v?sslmode=disable&connect_timeout=%v", user, password, host, port, dbname, timeout),
	}
	// 参数日志
	logging.Debugf("User: %s", conf.User)
	logging.Debugf("Port: %s", conf.Port)
	logging.Debugf("Password: %s", conf.Password)
	logging.Debugf("LogLevel: %s", conf.LogLevel)
	logging.Debugf("Dsn: %s", conf.Dsn)

	exporter := collector.New(conf)
	// The method is typically used exporter.Stop
	go collector.ListenSignal(exporter.Stop)
	registry := prometheus.NewRegistry()
	registry.MustRegister(exporter)
	http.Handle(*metricPath, promhttp.HandlerFor(registry, promhttp.HandlerOpts{}))
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		w.Write(landingPage)
	})
	logging.Infoln("Listening on", *listenAddress)
	logging.Fatal(http.ListenAndServe(*listenAddress, nil))
}
