package logger

import (
	"vastbase_exporter/common"
)

const (
	DefaultLogPath = "/tmp/" + common.NameSpace + ".log"
	OsSeparator    = "/"
)
