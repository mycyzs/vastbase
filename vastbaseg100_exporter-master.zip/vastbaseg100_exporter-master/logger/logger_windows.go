package logger

import (
	"vastbase_exporter/common"
)

const (
	DefaultLogPath = "C:\\gse\\logs\\" + common.NameSpace + ".log"
	OsSeparator    = "\\"
)
