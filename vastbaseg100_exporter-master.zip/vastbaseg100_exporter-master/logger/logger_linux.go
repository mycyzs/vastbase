package logger

import (
	"vastbase_exporter/common"
)

const (
	DefaultLogPath = "/var/log/gse/" + common.NameSpace + ".log"
	OsSeparator    = "/"
)
