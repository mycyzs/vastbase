版本支持

* 系统支持：Linux、Windows
* 版本支持：postgresql-9.6
* 插件版本：1.0

### 插件功能

采集器将会根据你配置的数据库IP和端口，定期在本地执行sql语句，以获取相应的指标数据。

## 使用指引

使用中可能遇到的问题：

- psql: 致命错误: 用户 "postgres" Ident 认证失败
  修改认证文件/var/lib/pgsql/data/pg_hba.conf，登陆使用密码。
  vi /var/lib/pgsql/data/pg_hba.conf
  把这个配置文件中的认证 METHOD的ident修改为trust，可以实现用账户和密码来访问数据库
  重启postgresql服务器使设置生效
- 如果没有pg_stat_statements表,在data/postgresql.conf中，进行配置：
  shared_preload_libraries = 'pg_stat_statements'      
  pg_stat_statements.max = 1000
  pg_stat_statements.track = all
  重新启动 postgresql，创建sql语句：
  create extension pg_stat_statements;

## 参数介绍

| 参数名             | 含义                                | 是否必填 | 使用举例       |
| ------------------ | ----------------------------------- | -------- | -------------- |
| web.listen-address | exporter监听的url，提供给采集器使用 | 否       | 127.0.0.1:9601 |
| web.telemetry-path | exporter采集到的数据显示路径        | 否       | /metrics       |
| host               | 数据库host地址              | 是       | 127.0.0.1      |
| port               | 数据库端口号          | 是       | 5432          |
| user               | 采集目标的用户名,默认为空           | 是       | postgres       |
| password           | 采集目标认证密码，默认为空          | 是       | 123456         |
| logLevel           | 采集目标的日志等级，默认为error     | 否       | info           |

### 指标列表

| 指标                                         | 指标别名                     | 单位 |
| -------------------------------------------- | ---------------------------- | ---- |
| postgresql_exporter_up                       | 实例运行状态                 |      |
| postgresql_exporter_connect_number           | 数据库连接数                 |      |
| postgresql_exporter_buffers_hit_rate         | 缓冲区缓存命中率             | %    |
| postgresql_exporter_tup_returned             | 全表扫描记录数               |      |
| postgresql_exporter_deadlock_number          | 死锁数                       |      |
| postgresql_exporter_xact_commit              | 数据库中已提交的事务数       |      |
| postgresql_exporter_xact_rollback            | 此数据库中已回滚的事务数     |      |
| postgresql_exporter_queries_per_second       | 每秒查询次数                 |      |
| postgresql_exporter_slow_query_number        | 慢查询数量                   |      |
| postgresql_exporter_database_used_disk_kb    | 数据库使用的磁盘空间         | kb   |
| postgresql_exporter_buffers_checkpoint       | 检查点期间写入的缓冲区数     |      |
| postgresql_exporter_buffers_clean            | 后台编写器写入的缓冲区数     |      |
| postgresql_exporter_buffers_backend          | 后端直接写入的缓冲区数       |      |
| postgresql_exporter_checkpoint_write_rate    | 检查点期间写入率             | %    |
| postgresql_exporter_lag_between_master_slave | 主站和从站之间的字节延迟     | s    |
| postgresql_exporter_lag_behind_master        | 从服务器滞后于主服务器几秒钟 | s    |

### 版本日志

