package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

func scrapeDbStatus(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: xact_commit, xact_rollback", serverVersion)
		return nil
	}
	rows, err := db.Query(`select datname,numbackends,xact_commit,xact_rollback,blks_read,blks_hit,tup_returned,tup_fetched,tup_inserted,tup_updated,tup_deleted,conflicts,temp_files,temp_bytes,deadlocks,blk_read_time,blk_write_time,stats_reset from dbe_perf.STAT_DATABASE where datname not in('template0','template1') order by deadlocks desc,xact_commit desc`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			datname        string
			numbackends    float64
			xact_commit    float64
			xact_rollback  float64
			blks_read      float64
			blks_hit       float64
			tup_returned   float64
			tup_fetched    float64
			tup_inserted   float64
			tup_updated    float64
			tup_deleted    float64
			conflicts      float64
			temp_files     float64
			temp_bytes     float64
			deadlocks      float64
			blk_read_time  float64
			blk_write_time float64
			stats_reset    string
		)
		if err := rows.Scan(&datname, &numbackends, &xact_commit, &xact_rollback, &blks_read, &blks_hit, &tup_returned, &tup_fetched, &tup_inserted, &tup_updated, &tup_deleted, &conflicts, &temp_files, &temp_bytes, &deadlocks, &blk_read_time, &blk_write_time, &stats_reset); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("xact_commit", "已提交事务数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, xact_commit, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("xact_rollback", "已回滚事务数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, xact_rollback, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("num_backends", "后端连接数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, numbackends, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("blks_read", "读取磁盘块次数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, blks_read, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("blks_hit", "已发现磁盘块次数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, blks_hit, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("tup_returned_number", "查询返回行数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, tup_returned, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("tup_fetched", "查询抓取行数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, tup_fetched, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("tup_inserted", "查询插入行数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, tup_inserted, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("tup_updated", "查询更新行数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, tup_updated, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("tup_deleted", "查询删除行数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, tup_deleted, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("conflicts", "取消查询数量",
			[]string{"DatabaseName"}), prometheus.GaugeValue, conflicts, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("temp_files", "创建临时文件数量",
			[]string{"DatabaseName"}), prometheus.GaugeValue, temp_files, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("temp_bytes", "写入临时文件数据总量",
			[]string{"DatabaseName"}), prometheus.GaugeValue, temp_bytes, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("deadlock_number", "死锁数",
			[]string{"DatabaseName"}), prometheus.GaugeValue, deadlocks, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("blk_read_time", "读取数据文件块耗时",
			[]string{"DatabaseName"}), prometheus.GaugeValue, blk_read_time, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("blk_write_time", "写入数据文件块耗时",
			[]string{"DatabaseName"}), prometheus.GaugeValue, blk_write_time, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("stats_reset", "重置当前状态统计的时间",
			[]string{"DatabaseName", "stats_reset"}), prometheus.GaugeValue, 0, datname, stats_reset)
	}

	return nil
}
