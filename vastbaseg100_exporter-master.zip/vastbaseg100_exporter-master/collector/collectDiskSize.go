package collector

import (
	"context"
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
	"time"
)

func scrapeDisk(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: database_used_disk_kb", serverVersion)
		return nil
	}
	// 有出现过超大数据量查询时间达到5m的情况
	ctx, _ := context.WithTimeout(context.TODO(), 3*time.Second)
	rows, err := db.QueryContext(ctx, `SELECT d.datname AS datname, CASE WHEN pg_catalog.has_database_privilege(d.datname, 'CONNECT') THEN pg_catalog.pg_database_size(d.datname) END AS size FROM pg_catalog.pg_database d;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			datname string
			size    float64
		)
		if err := rows.Scan(&datname, &size); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("database_used_disk_kb", "数据库使用的磁盘空间(kb)",
			[]string{"DatabaseName"}), prometheus.GaugeValue, size/1024, datname)
	}
	return nil
}
