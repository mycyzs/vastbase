package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

// 用户密码到期时间
func scrapeUser(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select rolname,round(extract(epoch from rolvaliduntil-now())/86400,2) valid_days from pg_authid order by rolvaliduntil;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			roleName      string
			rolValidUntil sql.NullFloat64
		)
		if err := rows.Scan(&roleName, &rolValidUntil); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("user_pass_valid", "用户密码到期时间",
			[]string{"rolename"}), prometheus.GaugeValue, rolValidUntil.Float64, roleName)
	}
	return nil
}
