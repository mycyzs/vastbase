package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

func scrapeWaitInfo(db *sql.DB, ch chan<- prometheus.Metric) error {
	// 当前等待事件数量
	var connection float64
	if err := db.QueryRow(`select count(*) wait_count from pg_stat_activity where state in ('active', 'fastpath function call') and pid<>pg_backend_pid();`).Scan(&connection); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("wait", "当前等待事件数量", nil),
		prometheus.GaugeValue, connection)

	// 历史等待事件数量累计
	var (
		historyType          string
		historyConnectionNum float64
	)
	if err := db.QueryRow(`select type,count(1) as num  from dbe_perf.WAIT_EVENTS group by type;`).Scan(&historyType, &historyConnectionNum); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("history_wait", "历史等待事件数量累计", []string{"type"}),
		prometheus.GaugeValue, historyConnectionNum, historyType)

	return nil
}
