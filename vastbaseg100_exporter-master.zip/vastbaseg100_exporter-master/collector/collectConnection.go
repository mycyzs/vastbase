package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

var blockConnectionListSQL = `with recursive tmp_lock as (
    select distinct
           w.pid as id,
           r.pid as parentid
    from (
          select a.mode,a.locktype,a.database,
                 a.relation,a.page,a.tuple,a.classid,
                 a.objid,a.objsubid,a.pid,a.virtualtransaction,a.virtualxid,
                 a.transactionid,
                 b.query as query,
                 b.xact_start,b.query_start,b.usename,b.datname 
           from pg_locks a,
                pg_stat_activity b 
          where a.pid=b.pid 
            and not a.granted 
          ) w,
         (
          select a.mode,a.locktype,a.database,
                 a.relation,a.page,a.tuple,a.classid,
                 a.objid,a.objsubid,a.pid,a.virtualtransaction,a.virtualxid,
                 a.transactionid,
                 b.query as query,
                 b.xact_start,b.query_start,b.usename,b.datname 
            from pg_locks a,
                 pg_stat_activity b -- select pg_typeof(pid) from pg_stat_activity
           where a.pid=b.pid 
             and a.granted 
          ) r 
    where 1=1
      and r.locktype is not distinct from w.locktype 
      and r.database is not distinct from w.database 
      and r.relation is not distinct from w.relation 
      and r.page is not distinct from w.page 
      and r.tuple is not distinct from w.tuple 
      and r.classid is not distinct from w.classid 
      and r.objid is not distinct from w.objid 
      and r.objsubid is not distinct from w.objsubid 
      and r.transactionid is not distinct from w.transactionid 
      and r.pid <> w.pid
),tmp0 as (
  select *
    from tmp_lock tl
   union all
  --查找root，同一时刻可能有多个root
  select t1.parentid,0::int4
    from tmp_lock t1
   where 1=1
     and t1.parentid not in (select id from tmp_lock)
),tmp3 (pathid,depth,id,parentid) as (
  --对过滤出的机构向下递归，构成tree
  SELECT array[id]::text[] as pathid,1 as depth,id,parentid
    FROM tmp0
   where 1=1
     and parentid=0
   union
  SELECT t0.pathid||array[t1.id]::text[] as pathid,t0.depth+1 as depth,t1.id,t1.parentid
    FROM tmp0 t1,  
         tmp3 t0
   where 1=1
     and t1.parentid=t0.id
)
select distinct 
       '/'||array_to_string(a0.pathid,'/') as pathid,
       a0.depth,
       a0.id,a0.parentid,lpad(a0.id::text, 2*a0.depth-1+length(a0.id::text),' ') as tree_id,
       a2.datname,a2.usename,a2.application_name,a2.client_addr,a2.state
       --,a2.backend_start,a2.xact_start,a2.query_start
  from tmp3 a0
       left outer join (select distinct '/'||id||'/' as prefix_id,id
                        from tmp0
             where 1=1 ) a1
                  on position( a1.prefix_id in '/'||array_to_string(a0.pathid,'/')||'/' ) >0
     left outer join pg_stat_activity a2 -- select * from pg_stat_activity
                  on a0.id = a2.pid
order by '/'||array_to_string(a0.pathid,'/'),a0.depth;`

func scrapeDBConnection(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: connections, connection_used_ratio", serverVersion)
		return nil
	}

	// 获取当前会话数
	var connection float64
	if err := db.QueryRow(`SELECT count(*) FROM pg_stat_activity;`).Scan(&connection); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("connections", "数据库连接数", nil),
		prometheus.GaugeValue, connection)

	// 最大会话数
	var maxConnections float64
	if err := db.QueryRow(`SELECT current_setting('max_connections') as max_count;`).Scan(&maxConnections); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("max_connections", "最大会话数", nil),
		prometheus.GaugeValue, maxConnections)

	// 获取活跃会话数
	var activeConnections float64
	if err := db.QueryRow(`SELECT count(*) as count FROM pg_stat_activity where state = 'active';`).Scan(&activeConnections); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("active_connections", "活跃会话数", nil),
		prometheus.GaugeValue, activeConnections)

	// 当前会话数比例
	ch <- prometheus.MustNewConstMetric(NewDesc("connection_used_ratio", "当前会话数比例", nil),
		prometheus.GaugeValue, 100*activeConnections/maxConnections)

	// 阻塞会话数
	var blockConnections float64
	if err := db.QueryRow(`select count(*) block_count from pg_locks where granted = 'f';`).Scan(&blockConnections); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("block_connections", "阻塞会话数", nil),
		prometheus.GaugeValue, blockConnections)

	// 获取空闲会话数
	var idleConnections float64
	if err := db.QueryRow(`select count(*) as count from pg_stat_activity where state in ('idle','idle in transaction');`).Scan(&idleConnections); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("idle_connections", "空闲会话数", nil),
		prometheus.GaugeValue, idleConnections)

	return nil
}

// 阻塞会话列表
func scrapeDBBlockConnection(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(blockConnectionListSQL)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			pathid         string
			depth          float64
			id             string
			parentid       string
			treeid         string
			datname        string
			usename        string
			applicatioName string
			clientAddr     string
			state          string
		)
		if err := rows.Scan(&pathid, &depth, &id, &parentid, &treeid, &datname, &usename, &applicatioName, &clientAddr, &state); err != nil {
			return err
		}

	}
	return nil
}
