package collector

import (
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
)

// 大表监控
func scrapeTable(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select current_database(),table_name,pg_relation_size(table_schema||'.'||table_name) as size_bytes
from information_schema.tables
where table_schema not in ('pg_catalog', 'information_schema')
order by size_bytes desc
LIMIT 10;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			current_database string
			table_name       string
			size_bytes       float64
		)
		if err := rows.Scan(&current_database, &table_name, &size_bytes); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("size_bytes", "表大小",
			[]string{"DatabaseName", "TableName"}), prometheus.GaugeValue, size_bytes, current_database, table_name)
	}
	return nil
}

// 表空间使用量
func scrapeTableUsage(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select pg_tablespace_size(spcname)/1024/1024 as tablespace_total_usedmsize,spcname,
            case when pg_tablespace_location(oid) = '' then (select setting from pg_settings where name = 'data_directory') 
            else pg_tablespace_location(oid) end from pg_tablespace;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			tablespace_total_usedmsize float64
			spcname                    string
			pg_tablespace_location     string
		)
		if err := rows.Scan(&tablespace_total_usedmsize, &spcname, &pg_tablespace_location); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("tablespace_total_usedmsize", "表已用空间大小",
			[]string{"spcname", "pg_tablespace_location"}), prometheus.GaugeValue, tablespace_total_usedmsize, spcname, pg_tablespace_location)
	}
	return nil
}

// 表膨胀
func scrapeTableBloat(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`SELECT
  current_database() AS db, schemaname, tablename, reltuples::bigint AS tups, relpages::bigint AS pages, otta,
  ROUND(CASE WHEN otta=0 OR sml.relpages=0 OR sml.relpages=otta THEN 0.0 ELSE sml.relpages/otta::numeric END,1) AS tbloat,
  CASE WHEN relpages < otta THEN 0 ELSE relpages::bigint - otta END AS wastedpages,
  CASE WHEN relpages < otta THEN 0 ELSE bs*(sml.relpages-otta)::bigint END AS wastedbytes,
  CASE WHEN relpages < otta THEN $$0 bytes$$::text ELSE (bs*(relpages-otta))::bigint || $$ bytes$$ END AS wastedsize,
  iname, ituples::bigint AS itups, ipages::bigint AS ipages, iotta,
  ROUND(CASE WHEN iotta=0 OR ipages=0 OR ipages=iotta THEN 0.0 ELSE ipages/iotta::numeric END,1) AS ibloat,
  CASE WHEN ipages < iotta THEN 0 ELSE ipages::bigint - iotta END AS wastedipages,
  CASE WHEN ipages < iotta THEN 0 ELSE bs*(ipages-iotta) END AS wastedibytes,
  CASE WHEN ipages < iotta THEN $$0 bytes$$ ELSE (bs*(ipages-iotta))::bigint || $$ bytes$$ END AS wastedisize,
  CASE WHEN relpages < otta THEN
    CASE WHEN ipages < iotta THEN 0 ELSE bs*(ipages-iotta::bigint) END
    ELSE CASE WHEN ipages < iotta THEN bs*(relpages-otta::bigint)
      ELSE bs*(relpages-otta::bigint + ipages-iotta::bigint) END
  END AS totalwastedbytes
FROM (
  SELECT
    nn.nspname AS schemaname,
    cc.relname AS tablename,
    COALESCE(cc.reltuples,0) AS reltuples,
    COALESCE(cc.relpages,0) AS relpages,
    COALESCE(bs,0) AS bs,
    COALESCE(CEIL((cc.reltuples*((datahdr+ma-
      (CASE WHEN datahdr%ma=0 THEN ma ELSE datahdr%ma END))+nullhdr2+4))/(bs-20::float)),0) AS otta,
    COALESCE(c2.relname,$$?$$) AS iname, COALESCE(c2.reltuples,0) AS ituples, COALESCE(c2.relpages,0) AS ipages,
    COALESCE(CEIL((c2.reltuples*(datahdr-12))/(bs-20::float)),0) AS iotta -- very rough approximation, assumes all cols
  FROM
     pg_class cc
  JOIN pg_namespace nn ON cc.relnamespace = nn.oid AND nn.nspname <> $$information_schema$$
  LEFT JOIN
  (
    SELECT
      ma,bs,foo.nspname,foo.relname,
      (datawidth+(hdr+ma-(case when hdr%ma=0 THEN ma ELSE hdr%ma END)))::numeric AS datahdr,
      (maxfracsum*(nullhdr+ma-(case when nullhdr%ma=0 THEN ma ELSE nullhdr%ma END))) AS nullhdr2
    FROM (
      SELECT
        ns.nspname, tbl.relname, hdr, ma, bs,
        SUM((1-coalesce(null_frac,0))*coalesce(avg_width, 2048)) AS datawidth,
        MAX(coalesce(null_frac,0)) AS maxfracsum,
        hdr+(
          SELECT 1+count(*)/8
          FROM pg_stats s2
          WHERE null_frac<>0 AND s2.schemaname = ns.nspname AND s2.tablename = tbl.relname
        ) AS nullhdr
      FROM pg_attribute att 
      JOIN pg_class tbl ON att.attrelid = tbl.oid
      JOIN pg_namespace ns ON ns.oid = tbl.relnamespace 
      LEFT JOIN pg_stats s ON s.schemaname=ns.nspname
      AND s.tablename = tbl.relname
      AND s.inherited=false
      AND s.attname=att.attname,
      (
        SELECT
          (SELECT current_setting($$block_size$$)::numeric) AS bs,
            CASE WHEN SUBSTRING(SPLIT_PART(v, $$ $$, 2) FROM $$#""[0-9]+.[0-9]+#""%$$ for $$#$$)
              IN ($$8.0$$,$$8.1$$,$$8.2$$) THEN 27 ELSE 23 END AS hdr,
          CASE WHEN v ~ $$mingw32$$ OR v ~ $$64-bit$$ THEN 8 ELSE 4 END AS ma
        FROM (SELECT version() AS v) AS foo
      ) AS constants
      WHERE att.attnum > 0 AND tbl.relkind=$$r$$
      GROUP BY 1,2,3,4,5
    ) AS foo
  ) AS rs
  ON cc.relname = rs.relname AND nn.nspname = rs.nspname
  LEFT JOIN pg_index i ON indrelid = cc.oid
  LEFT JOIN pg_class c2 ON c2.oid = i.indexrelid
) AS sml order by wastedbytes desc limit 5;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			dbname           string
			schemaname       string
			tablename        string
			tups             float64
			pages            float64
			otta             float64
			tbloat           float64
			wastedpages      float64
			wastedbytes      float64
			wastedsize       string
			iname            string
			itups            float64
			ipages           float64
			iotta            float64
			ibloat           float64
			wastedipages     float64
			wastedibytes     float64
			wastedisize      string
			totalwastedbytes float64
		)
		if err := rows.Scan(&dbname, &schemaname, &tablename, &tups, &pages, &otta, &tbloat, &wastedpages, &wastedbytes, &wastedsize, &iname, &itups, &ipages, &iotta, &ibloat, &wastedipages, &wastedibytes, &wastedisize, &totalwastedbytes); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("table_bloat_tups", "表膨胀行数",
			[]string{"DatabaseName", "SchemaName", "TableName", "IName"}), prometheus.GaugeValue, tups, dbname, schemaname, tablename, iname)
		ch <- prometheus.MustNewConstMetric(NewDesc("table_bloat_pages", "表膨胀占用数据库块数",
			[]string{"DatabaseName", "SchemaName", "TableName", "IName"}), prometheus.GaugeValue, pages, dbname, schemaname, tablename, iname)
		ch <- prometheus.MustNewConstMetric(NewDesc("table_bloat_otta", "表膨胀预估数据块",
			[]string{"DatabaseName", "SchemaName", "TableName", "IName"}), prometheus.GaugeValue, otta, dbname, schemaname, tablename, iname)
		ch <- prometheus.MustNewConstMetric(NewDesc("table_bloat_tbloat", "表膨胀倍数",
			[]string{"DatabaseName", "SchemaName", "TableName", "IName"}), prometheus.GaugeValue, tbloat, dbname, schemaname, tablename, iname)
		//ch <- prometheus.MustNewConstMetric(NewDesc("table_bloat_wastedsize", "表膨胀浪费空间大小",
		//	[]string{"DatabaseName", "SchemaName", "TableName", "IName"}), prometheus.GaugeValue, wastedsize,dbname, schemaname, tablename)
	}
	return nil
}
