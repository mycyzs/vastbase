package collector

import (
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
)

// >=9.2
func scrapeSlowQueryNum(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(90200, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: slow_query_number", serverVersion)
		return nil
	}
	rows, err := db.Query(`SELECT count(*) FROM pg_stat_activity WHERE STATE = 'active' AND now( ) - query_start > INTERVAL '1 second';`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			count float64
		)
		if err := rows.Scan(&count); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("slow_query_number", "慢查询数量", nil),
			prometheus.GaugeValue, count)
	}
	return nil
}

// 8.x
func scrapeSlowQueryNumFor8(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(80200, 90200)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: slow_query_number", serverVersion)
		return nil
	}
	var count float64
	if err := db.QueryRow(`SELECT count(*) FROM pg_stat_activity WHERE waiting = 'f' AND now( ) - query_start > INTERVAL '1 second';`).Scan(&count); err != nil {
		return err
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("slow_query_number", "慢查询数量", nil),
		prometheus.GaugeValue, count)
	return nil
}
