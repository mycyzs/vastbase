package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

var backUpStateMap = map[string]float64{
	"Startup":   1,
	"Catchup":   2,
	"Streaming": 3,
	"Backup":    4,
	"Stopping":  5,
}

var backUpSyncStateMap = map[string]float64{
	"Async":     1,
	"Potential": 2,
	"Sync":      3,
	"Quorum":    4,
}

// 主备流复制状态
func scrapeBackUp(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`SELECT 
       usename, application_name, client_addr, client_hostname, client_port, backend_start, state, sync_state,      
       pg_xlog_location_diff(A .c1, receiver_replay_location) /(1024 * 1024) AS slave_latency_MB,
       pg_xlog_location_diff(A .c1, sender_sent_location) /(1024 * 1024) AS send_latency_MB,
       pg_xlog_location_diff(A .c1, receiver_flush_location) /(1024 * 1024) AS flush_latency_MB,
       now()::timestamptz AS query_time
   FROM pg_stat_replication, pg_current_xlog_location() AS A(c1);`)
	if err != nil {
		return err
	}
	logging.Debug("start scrape back up.")
	defer rows.Close()
	for rows.Next() {
		var (
			usename         sql.NullString
			applicationName sql.NullString
			clientAddr      sql.NullString
			clientHostName  sql.NullString
			clientPort      sql.NullString
			backendStart    sql.NullString
			state           string
			syncState       string
			slaveLatencyMB  float64
			sendLatencyMB   float64
			flushLatencyMB  float64
			queryTime       string
		)
		if err := rows.Scan(&usename, &applicationName, &clientAddr, &clientHostName, &clientPort, &backendStart, &state, &syncState, &slaveLatencyMB, &sendLatencyMB, &flushLatencyMB, &queryTime); err != nil {
			return err
		}

		ch <- prometheus.MustNewConstMetric(NewDesc("backup_state", "主备进程状态",
			[]string{"application_name", "client_addr", "backendStart"}), prometheus.GaugeValue, backUpStateMap[state],
			applicationName.String, clientAddr.String, backendStart.String)
		ch <- prometheus.MustNewConstMetric(NewDesc("backup_syncState", "主备同步状态",
			[]string{"application_name", "client_addr", "backendStart"}), prometheus.GaugeValue, backUpSyncStateMap[syncState],
			applicationName.String, clientAddr.String, backendStart.String)
		ch <- prometheus.MustNewConstMetric(NewDesc("slaveLatencyMB", "备库WAL延迟应用量",
			[]string{"application_name", "client_addr", "backendStart"}), prometheus.GaugeValue, slaveLatencyMB,
			applicationName.String, clientAddr.String, backendStart.String)
		ch <- prometheus.MustNewConstMetric(NewDesc("sendLatencyMB", "备库WAL延迟接收量",
			[]string{"application_name", "client_addr", "backendStart"}), prometheus.GaugeValue, sendLatencyMB,
			applicationName.String, clientAddr.String, backendStart.String)
		ch <- prometheus.MustNewConstMetric(NewDesc("flushLatencyMB", "备库WAL延迟刷盘量",
			[]string{"application_name", "client_addr", "backendStart"}), prometheus.GaugeValue, flushLatencyMB,
			applicationName.String, clientAddr.String, backendStart.String)
	}
	return nil
}
