package collector

import (
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
)

func scrapeLocksInfo(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: granted_locks", serverVersion)
		return nil
	}
	rows, err := db.Query(`SELECT CASE WHEN datname is null THEN 'null' ELSE datname END, count(*) FROM pg_catalog.pg_locks l LEFT OUTER JOIN pg_catalog.pg_database d ON (l.database = d.oid) where l.granted = true group by datname;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	var (
		datname string
		locks   float64
	)
	for rows.Next() {

		if err := rows.Scan(&datname, &locks); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("granted_locks", "数据库中当前已授予的锁数量",
			[]string{"DatabaseName"}), prometheus.GaugeValue, locks, datname)
	}

	return nil

}

func ScrapeLocksDetail(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: db_locks", serverVersion)
		return nil
	}
	rows, err := db.Query(`select pg_database.datname,tmp.mode,COALESCE(count,0) as count
FROM (VALUES ('accesssharelock'), ('rowsharelock'), ('rowexclusivelock'), ('shareupdateexclusivelock'), ('sharelock'),
('sharerowexclusivelock'), ('exclusivelock'), ('accessexclusivelock'), ('sireadlock')) AS tmp(mode) CROSS JOIN pg_database
LEFT JOIN (SELECT database, lower(mode) AS mode,count(*) AS count FROM pg_locks WHERE database IS NOT NULL GROUP BY database, lower(mode)) AS tmp2
ON tmp.mode=tmp2.mode and pg_database.oid = tmp2.database ORDER BY 1;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	var (
		datname string
		mode    string
		count   float64
	)
	for rows.Next() {
		if err := rows.Scan(&datname, &mode, &count); err != nil {
			logging.Debugln("get locksDetail from rows error ", err)
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("db_locks", "数据库中不同类型锁的数量",
			[]string{"DatabaseName", "LockMode"}), prometheus.GaugeValue, count, datname, mode)
	}
	return nil

}
