package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

// WAL统计信息
func scrapeWal(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select phywrts,phyblkwrt,writetim,avgiotim ,lstiotim,miniotim ,maxiowtm from dbe_perf.FILE_REDO_IOSTAT;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			phywrts   float64
			phyblkwrt float64
			writetim  float64
			avgiotim  float64
			lstiotim  float64
			miniotim  float64
			maxiowtm  float64
		)
		if err := rows.Scan(&phywrts, &phyblkwrt, &writetim, &avgiotim, &lstiotim, &miniotim, &maxiowtm); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("wal_write_buffer", "wal_buffer写次数",
			nil), prometheus.GaugeValue, phywrts)
		ch <- prometheus.MustNewConstMetric(NewDesc("wal_write_block_buffer", "wal_buffer写block次数",
			nil), prometheus.GaugeValue, phyblkwrt)
	}
	return nil
}
