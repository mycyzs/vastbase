package collector

import (
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
)

func scrapeQPS(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: queries_per_second", serverVersion)
		return nil
	}

	// 查询
	var queryCount float64
	if err := db.QueryRow(`WITH a AS (SELECT SUM(calls) s FROM pg_stat_statements), b AS (SELECT SUM(calls) s FROM pg_stat_statements , pg_sleep(1))
SELECT b.s-a.s AS count FROM a,b;`).Scan(&queryCount); err != nil {
		return err
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("queries_per_second", "每秒查询次数", nil),
		prometheus.GaugeValue, queryCount)

	// 更新
	var updateCount float64
	if err := db.QueryRow(`with                                               
a as (select sum(tup_updated) s from pg_stat_database),   
b as (select sum(tup_updated) s from pg_stat_database , pg_sleep(1))   
select   
b.s-a.s as updated
from a,b;`).Scan(&updateCount); err != nil {
		return err
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("update_per_second", "每秒更新次数", nil),
		prometheus.GaugeValue, updateCount)

	// 读取磁盘
	var readCount float64
	if err := db.QueryRow(`with                                               
a as (select sum(blks_read) s from pg_stat_database),   
b as (select sum(blks_read) s from pg_stat_database , pg_sleep(1))   
select   
b.s-a.s as read
from a,b;`).Scan(&readCount); err != nil {
		return err
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("read_per_second", "每秒读取磁盘次数", nil),
		prometheus.GaugeValue, readCount)

	// 删除
	var deleteCount float64
	if err := db.QueryRow(`with                                               
a as (select sum(tup_deleted) s from pg_stat_database),   
b as (select sum(tup_deleted) s from pg_stat_database , pg_sleep(1))   
select   
b.s-a.s as deleted
from a,b;`).Scan(&deleteCount); err != nil {
		return err
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("delete_per_second", "每秒删除次数", nil),
		prometheus.GaugeValue, deleteCount)

	// 插入
	var insertCount float64
	if err := db.QueryRow(`with                                               
a as (select sum(tup_inserted) s from pg_stat_database),   
b as (select sum(tup_inserted) s from pg_stat_database , pg_sleep(1))   
select   
b.s-a.s as inserted
from a,b;`).Scan(&insertCount); err != nil {
		return nil
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("insert_per_second", "每秒插入次数", nil),
		prometheus.GaugeValue, insertCount)

	// 扫描
	var fetchCount float64
	if err := db.QueryRow(`with                                               
a as (select sum(tup_fetched) s from pg_stat_database),   
b as (select sum(tup_fetched) s from pg_stat_database , pg_sleep(1))   
select   
b.s-a.s as fetched
from a,b;`).Scan(&fetchCount); err != nil {
		return nil
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("fetch_per_second", "每秒索引扫描回表记录数", nil),
		prometheus.GaugeValue, fetchCount)

	// TPS
	var TPS float64
	if err := db.QueryRow(`with                                               
a as (select sum(calls) s, sum(case when ltrim(query,' ') ~* '^select' then calls else 0 end) q from pg_stat_statements),   
b as (select sum(calls) s, sum(case when ltrim(query,' ') ~* '^select' then calls else 0 end) q from pg_stat_statements , pg_sleep(1))   
select   
b.s-b.q-a.s+a.q tps
from a,b;`).Scan(&TPS); err != nil {
		return nil
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("TPS", "TPS", nil),
		prometheus.GaugeValue, TPS)

	// QPS
	var QPS float64
	if err := db.QueryRow(`with                                               
a as (select sum(calls) s from pg_stat_statements),   
b as (select sum(calls) s from pg_stat_statements , pg_sleep(1))   
select   
b.s-a.s qps
from a,b;`).Scan(&TPS); err != nil {
		return nil
	}
	ch <- prometheus.MustNewConstMetric(NewDesc("QPS", "QPS", nil),
		prometheus.GaugeValue, QPS)

	return nil
}
