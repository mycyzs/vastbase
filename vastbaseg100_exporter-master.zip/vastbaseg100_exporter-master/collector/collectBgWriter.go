package collector

import (
	"database/sql"
	"github.com/prometheus/client_golang/prometheus"
)

// >=8.4
func scrapeBgWriter(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(80400, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: buffers_clean, buffers_checkpoint, buffers_backend, checkpoint_write_ratio", serverVersion)
		return nil
	}
	rows, err := db.Query(`SELECT buffers_clean, buffers_checkpoint, buffers_backend FROM pg_stat_bgwriter;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			buffers_clean          float64
			buffers_checkpoint     float64
			buffers_backend        float64
			checkpoint_write_ratio float64
		)
		if err := rows.Scan(&buffers_clean, &buffers_checkpoint, &buffers_backend); err != nil {
			return err
		}
		checkpoint_write_ratio = buffers_checkpoint / (buffers_checkpoint + buffers_clean + buffers_backend + 0.000001)
		ch <- prometheus.MustNewConstMetric(NewDesc("buffers_clean", "后台编写器写入的缓冲区数", nil),
			prometheus.GaugeValue, buffers_clean)
		ch <- prometheus.MustNewConstMetric(NewDesc("buffers_checkpoint", "检查点期间写入的缓冲区数", nil),
			prometheus.GaugeValue, buffers_checkpoint)
		ch <- prometheus.MustNewConstMetric(NewDesc("buffers_backend", "后端直接写入的缓冲区数", nil),
			prometheus.GaugeValue, buffers_backend)
		ch <- prometheus.MustNewConstMetric(NewDesc("checkpoint_write_ratio", "检查点期间写入率", nil),
			prometheus.GaugeValue, checkpoint_write_ratio)
	}
	return nil
}
