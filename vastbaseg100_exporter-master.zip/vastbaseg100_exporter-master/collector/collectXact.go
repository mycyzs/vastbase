package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

func scrapeTransaction(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: xact_commit, xact_rollback", serverVersion)
		return nil
	}

	var long_xact float64
	if err := db.QueryRow(`SELECT count(*) long_xact FROM pg_stat_activity WHERE STATE <>'idle' and now()-xact_start > interval '30 SECOND';`).Scan(&long_xact); err != nil {
		return err
	}

	ch <- prometheus.MustNewConstMetric(NewDesc("long_xact_num", "执行时间大于30秒的长事务数",
		nil), prometheus.GaugeValue, long_xact)

	return nil
}

func scrapeMaxTranDuration(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: db_max_tran_duration", serverVersion)
		return nil
	}
	rows, err := db.Query(`select dtbs.datname, MAX(EXTRACT(EPOCH FROM now() - xact_start))::float AS maxduration from pg_stat_activity act right join pg_database dtbs on act.datname = dtbs.datname  group by dtbs.datname;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			datname     string
			maxDuration sql.NullFloat64
		)
		err := rows.Scan(&datname, &maxDuration)
		if err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("db_max_tran_duration", "数据库中当前执行事务的最长时间",
			[]string{"DatabaseName"}), prometheus.GaugeValue, maxDuration.Float64, datname)

	}

	return nil
}
