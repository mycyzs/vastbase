package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

func scrapeBufferHit(db *sql.DB, ch chan<- prometheus.Metric) error {
	validator := NewVersionValidor(0, 0)
	if !validator.Valid(serverVersion) {
		logging.Debugf("Version %v did not support the metric: buffers_hit_ratio", serverVersion)
		return nil
	}
	rows, err := db.Query(`SELECT a.datname,
CAST(blks_hit / (blks_read + blks_hit + 0.000001) * 100.0 AS NUMERIC(5, 2)) AS buffer_hit,
CAST(xact_commit / (xact_rollback + xact_commit + 0.000001) * 100.0 AS NUMERIC(5, 2)) AS success_trans
FROM pg_stat_database a
where datname not in ('template0','template1')
ORDER BY pg_database_size(a.datid) DESC;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			datname       string
			buffer_hit    float64
			success_trans float64
		)
		if err := rows.Scan(&datname, &buffer_hit, &success_trans); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("buffers_hit_ratio", "缓存命中率",
			[]string{"DatabaseName"}), prometheus.GaugeValue, buffer_hit, datname)
		ch <- prometheus.MustNewConstMetric(NewDesc("xact_trans_ratio", "事务提交率",
			[]string{"DatabaseName"}), prometheus.GaugeValue, success_trans, datname)
	}
	return nil
}
