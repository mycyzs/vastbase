package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

// 内存使用情况
func scrapeMemory(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select 
case when memorytype='max_process_memory'      then 'VastbaseG100实例允许占用的最大内存'
     when memorytype='process_used_memory'     then '数据库进程占用的内存'
     when memorytype='max_dynamic_memory'      then '最大动态内存'
     when memorytype='dynamic_used_memory'     then '已使用的动态内存'
     when memorytype='dynamic_peak_memory'     then '内存的动态峰值'
     when memorytype='dynamic_used_shrctx'     then '最大动态共享内存上下文'
     when memorytype='dynamic_peak_shrctx'     then '共享内存上下文的动态峰值'
     when memorytype='max_shared_memory'       then '最大共享内存'
     when memorytype='shared_used_memory'      then '已使用的共享内存'
     when memorytype='max_cstore_memory'       then '列存所允许使用的最大内存'
     when memorytype='cstore_used_memory'      then '列存已使用的内存大小'
     when memorytype='max_sctpcomm_memory'     then 'sctp通信所允许使用的最大内存'
     when memorytype='sctpcomm_used_memory'    then 'sctp通信已使用的内存大小'
     when memorytype='sctpcomm_peak_memory'    then 'sctp通信的内存峰值'
     when memorytype='other_used_memory'       then '其他已使用的内存大小'
     when memorytype='gpu_max_dynamic_memory'  then 'GPU最大动态内存'
     when memorytype='gpu_dynamic_used_memory' then 'GPU已使用的动态内存'
     when memorytype='gpu_dynamic_peak_memory' then 'GPU内存的动态峰值'
     when memorytype='pooler_conn_memory'      then '链接池申请内存计数'
     when memorytype='pooler_freeconn_memory'  then '链接池空闲连接的内存计数'
     when memorytype='storage_compress_memory' then '存储模块压缩使用的内存大小'
     when memorytype='udf_reserved_memory'     then 'UDF预留的内存大小'
	 else memorytype end as memorytype
	 ,memorymbytes from dbe_perf.MEMORY_NODE_DETAIL;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			memoryType   string
			memoryMbytes float64
		)
		if err := rows.Scan(&memoryType, &memoryMbytes); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("memory_info", "内存使用情况",
			[]string{"memoryType"}), prometheus.GaugeValue, memoryMbytes, memoryType)
	}
	return nil
}

// 内存使用率
func scrapeMemoryRatio(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`SELECT process_used_memory/max_process_memory as process_use_rate,
dynamic_used_memory/max_dynamic_memory as dynamic_use_rate,
shared_used_memory/max_shared_memory as shared_use_rate
  FROM pg_total_memory_detail pivot(
   sum(memorymbytes) for memorytype in ('max_process_memory' as max_process_memory,'process_used_memory' as process_used_memory,'max_dynamic_memory' as max_dynamic_memory,'dynamic_used_memory' as dynamic_used_memory, 'max_shared_memory' as max_shared_memory, 'shared_used_memory' as shared_used_memory ));`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			process_use_rate float64
			dynamic_use_rate float64
			shared_use_rate  float64
		)
		if err := rows.Scan(&process_use_rate, &dynamic_use_rate, &shared_use_rate); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("process_use_rate", "数据库进程使用内存占最大可用进程内存比例",
			nil), prometheus.GaugeValue, process_use_rate*100)
		ch <- prometheus.MustNewConstMetric(NewDesc("dynamic_use_rate", "数据库动态内存占最大可用动态内存比例",
			nil), prometheus.GaugeValue, dynamic_use_rate*100)
		ch <- prometheus.MustNewConstMetric(NewDesc("shared_use_rate", "数据库共享内存占最大可用共享内存比例",
			nil), prometheus.GaugeValue, shared_use_rate*100)
	}
	return nil
}

// scrapeSQLMemoryUsage 最耗共享内存SQL
func scrapeSQLMemoryUsage(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`SELECT
    pg_get_userbyid(stat.userid) as userid,
    db.datname,
    stat.query,
     (shared_blks_hit+shared_blks_dirtied)  as shared_blks
FROM
pg_stat_statements stat
LEFT OUTER JOIN pg_database db ON stat.dbid = db.oid
ORDER BY shared_blks DESC  limit 10;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			userID     sql.NullString
			datname    string
			query      string
			shard_blks float64
		)
		if err := rows.Scan(&userID, &datname, &query, &shard_blks); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("SQL_memory_useage", "SQL共享内存消耗",
			[]string{"userID", "DatabaseName", "query"}), prometheus.GaugeValue, shard_blks, userID.String, datname, query)
	}
	return nil
}
