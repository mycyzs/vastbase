package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

type ScrapeFn func(db *sql.DB, ch chan<- prometheus.Metric) error

// A map used to call the collect metrics method
var ScrapeFns = map[string]func(db *sql.DB, ch chan<- prometheus.Metric) error{
	"scrapeDbStatus":     scrapeDbStatus,
	"scrapeDBConnection": scrapeDBConnection,
	//"scrapeDBBlockConnection": scrapeDBBlockConnection,
	"scrapeTransaction":      scrapeTransaction,
	"scrapeMaxTranDuration":  scrapeMaxTranDuration,
	"scrapeBufferHit":        scrapeBufferHit,
	"scrapeLocksInfo":        scrapeLocksInfo,
	"ScrapeLocksDetail":      ScrapeLocksDetail,
	"scrapeDisk":             scrapeDisk,
	"scrapeSlowQueryNum":     scrapeSlowQueryNum,
	"scrapeSlowQueryNumFor8": scrapeSlowQueryNumFor8,
	"scrapeBgWriter":         scrapeBgWriter,
	"scrapeQPS":              scrapeQPS,
	"scrapeWaitInfo":         scrapeWaitInfo,
	"scrapeUser":             scrapeUser,
	"scrapeMemory":           scrapeMemory,
	"scrapeMemoryRatio":      scrapeMemoryRatio,
	//"scrapeTable":            scrapeTable,
	"scrapeTableUsage": scrapeTableUsage,
	"scrapeIndex":      scrapeIndex,
	"scrapeTableBloat": scrapeTableBloat,
	"scrapeBackUp":     scrapeBackUp,
	"scrapeScanTop10":  scrapeScanTop10,
	"scrapeWal":        scrapeWal,
	"scrapeTable":      scrapeTable,
	"dataBaseBasic":    dbConnectState,
	//"scrapeTopSQL1":        scrapeTopSQL1,
	//"scrapeTopSQL2":        scrapeTopSQL2,
	//"scrapeTopSQL3":        scrapeTopSQL3,
	//"scrapeTopSQL4":        scrapeTopSQL4,
	//"scrapeSQLMemoryUsage": scrapeSQLMemoryUsage,
}
