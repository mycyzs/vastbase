package collector

import (
	"database/sql"

	"github.com/prometheus/client_golang/prometheus"
)

// 顺序扫描TOP10
func scrapeScanTop10(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(`select relid,schemaname,relname,seq_scan,(n_live_tup+n_dead_tup)as n_all,n_live_tup,n_dead_tup  from dbe_perf.STAT_USER_TABLES where n_all>1000000 order by seq_scan desc,n_all desc limit 10;`)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			relid      float64
			schemaname string
			relname    float64
			seqScan    float64
			nAll       float64
			nLiveTup   float64
			nDeadTup   float64
		)
		if err := rows.Scan(&relid, &schemaname, &relname, &seqScan, &nAll, &nLiveTup, &nDeadTup); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("nDeadTup", "死元组数",
			[]string{"memoryType"}), prometheus.GaugeValue, nDeadTup)
		ch <- prometheus.MustNewConstMetric(NewDesc("seqScan", "顺序扫描次数",
			[]string{"memoryType"}), prometheus.GaugeValue, seqScan)
		ch <- prometheus.MustNewConstMetric(NewDesc("nAll", "总行数(含死行)",
			[]string{"memoryType"}), prometheus.GaugeValue, nAll)
		ch <- prometheus.MustNewConstMetric(NewDesc("nLiveTup", "活元组数",
			[]string{"memoryType"}), prometheus.GaugeValue, nLiveTup)
	}
	return nil
}

// scrapeTopSQL1 按单次执行时长排序
func scrapeTopSQL1(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(TOPSQL1)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			userID              sql.NullString
			datname             string
			query               string
			calls               float64
			totalTime           float64
			sqlRows             float64
			avgTime             float64
			shared_blks_read    float64
			shared_blks_dirtied float64
			shared_blks_written float64
			temp_blks_read      float64
			temp_blks_written   float64
		)
		if err := rows.Scan(&userID, &datname, &query, &calls, &totalTime, &sqlRows, &avgTime, &shared_blks_read, &shared_blks_dirtied, &shared_blks_written, &temp_blks_read, &temp_blks_written); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("SQL_avg_time", "SQL平均执行时长",
			[]string{"userID", "SQL_query", "DatabaseName"}), prometheus.GaugeValue, avgTime, userID.String, query, datname)
	}
	return nil
}

// scrapeTopSQL2 按执行次数排序
func scrapeTopSQL2(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(TOPSQL2)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			userID              sql.NullString
			datname             string
			query               string
			calls               float64
			totalTime           float64
			sqlRows             float64
			avgTime             float64
			shared_blks_read    float64
			shared_blks_dirtied float64
			shared_blks_written float64
			temp_blks_read      float64
			temp_blks_written   float64
		)
		if err := rows.Scan(&userID, &datname, &query, &calls, &totalTime, &sqlRows, &avgTime, &shared_blks_read, &shared_blks_dirtied, &shared_blks_written, &temp_blks_read, &temp_blks_written); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("SQL_calls", "SQL调用次数",
			[]string{"userID", "SQL_query", "DatabaseName"}), prometheus.GaugeValue, calls, userID.String, query, datname)
	}
	return nil
}

// scrapeTopSQL3 按执行总时间排序
func scrapeTopSQL3(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(TOPSQL3)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			userID              sql.NullString
			datname             string
			query               string
			calls               float64
			totalTime           float64
			sqlRows             float64
			avgTime             float64
			shared_blks_read    float64
			shared_blks_dirtied float64
			shared_blks_written float64
			temp_blks_read      float64
			temp_blks_written   float64
		)
		if err := rows.Scan(&userID, &datname, &query, &calls, &totalTime, &sqlRows, &avgTime, &shared_blks_read, &shared_blks_dirtied, &shared_blks_written, &temp_blks_read, &temp_blks_written); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("SQL_total_time", "SQL总执行时间",
			[]string{"userID", "SQL_query", "DatabaseName"}), prometheus.GaugeValue, totalTime, userID.String, query, datname)
	}
	return nil
}

// scrapeTopSQL4 慢查询大于1s
func scrapeTopSQL4(db *sql.DB, ch chan<- prometheus.Metric) error {
	rows, err := db.Query(TOPSQL3)
	if err != nil {
		return err
	}
	defer rows.Close()
	for rows.Next() {
		var (
			userID              sql.NullString
			datname             string
			query               string
			calls               float64
			totalTime           float64
			sqlRows             float64
			avgTime             float64
			shared_blks_read    float64
			shared_blks_dirtied float64
			shared_blks_written float64
			temp_blks_read      float64
			temp_blks_written   float64
		)
		if err := rows.Scan(&userID, &datname, &query, &calls, &totalTime, &sqlRows, &avgTime, &shared_blks_read, &shared_blks_dirtied, &shared_blks_written, &temp_blks_read, &temp_blks_written); err != nil {
			return err
		}
		ch <- prometheus.MustNewConstMetric(NewDesc("SQL_total_time", "SQL慢查询调用次数",
			[]string{"userID", "SQL_query", "DatabaseName"}), prometheus.GaugeValue, calls, userID.String, query, datname)
	}
	return nil
}

var TOPSQL1 = `SELECT
    pg_get_userbyid(stat.userid) as userid,
    db.datname,
    stat.query,
    stat.calls,
    stat.total_time,
    stat.rows,
    stat.total_time/stat.calls/1000 as avg_time,
    stat.shared_blks_read,
    stat.shared_blks_dirtied,
    stat.shared_blks_written,
    stat.temp_blks_read,
    stat.temp_blks_written
FROM pg_stat_statements stat
LEFT JOIN pg_database db ON stat.dbid = db.oid
WHERE query not ilike 'SET %' and
query not like '/* contrib/%'
and query not like '-- %'
ORDER BY total_time/calls DESC  limit 10;`

var TOPSQL2 = `SELECT
    pg_get_userbyid(stat.userid) as userid,
    db.datname,    
    stat.query,
    stat.calls,
    stat.total_time,
    stat.rows,
    stat.total_time/stat.calls/1000 as avg_time,
    stat.shared_blks_read,
    stat.shared_blks_dirtied,
    stat.shared_blks_written,
    stat.temp_blks_read,
    stat.temp_blks_written
FROM pg_stat_statements stat
LEFT JOIN pg_database db ON stat.dbid = db.oid
WHERE query not ilike 'SET %' and 
query not like '/* contrib/%' 
and query not like '-- %' 
ORDER BY stat.calls DESC  limit 10;`

var TOPSQL3 = `SELECT
    pg_get_userbyid(stat.userid) as userid,
    db.datname,    
    stat.query,
    stat.calls,
    stat.total_time,
    stat.rows,
    stat.total_time/stat.calls/1000 as avg_time,
    stat.shared_blks_read,
    stat.shared_blks_dirtied,
    stat.shared_blks_written,
    stat.temp_blks_read,
    stat.temp_blks_written
FROM pg_stat_statements stat
LEFT JOIN pg_database db ON stat.dbid = db.oid
WHERE query not ilike 'SET %' and 
query not like '/* contrib/%' 
and query not like '-- %' 
ORDER BY stat.total_time DESC  limit 10;`

var TOPSQL4 = `SELECT
    pg_get_userbyid(stat.userid) as userid,
    db.datname,    
    stat.query,
    stat.calls,
    stat.total_time,
    stat.rows,
    stat.total_time/stat.calls/1000 as avg_time,
    stat.shared_blks_read,
    stat.shared_blks_dirtied,
    stat.shared_blks_written,
    stat.temp_blks_read,
    stat.temp_blks_written
FROM pg_stat_statements stat
LEFT JOIN pg_database db ON stat.dbid = db.oid
WHERE query not ilike 'SET %' and 
query not like '/* contrib/%' 
and query not like '-- %' 
and stat.total_time/stat.calls > 1000
ORDER BY total_time/calls DESC ;`
