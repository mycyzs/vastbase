package collector

type VersionValidator struct {
	minV int
	maxV int
}

func (v VersionValidator) Valid(version int) bool {
	return v.minV <= version && version < v.maxV
}

func NewVersionValidor(minV int, maxV int) VersionValidator {
	if minV == 0 {
		minV = -1
	}
	if maxV == 0 {
		maxV = 99999999
	}
	return VersionValidator{
		minV: minV,
		maxV: maxV,
	}
}
